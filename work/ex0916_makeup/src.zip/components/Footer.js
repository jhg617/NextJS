
export default function Footer(){
    return(
        //하나의 태그만 전달해야함
        <div style={{width: '80%', margin: 'auto', padding: '20px',
            textAlign:'center'}}>
            Copyright &copy; 2025 대파-이음
        </div>
    );
};